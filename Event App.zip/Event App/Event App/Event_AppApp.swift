//
//  Event_AppApp.swift
//  Event App
//
//  Created by 张熙景 on 4/18/22.
//

import SwiftUI

@main
struct Event_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
